---
name: memory-service
description: Teaches Claude when to use memory services effectively - when to recall context, what to store, and how to maintain continuity across conversations. Use this skill at conversation start and before any substantial work.
---

# Memory Service

Quick patterns for using memory effectively.

## Philosophy

**Store liberally, recall proactively.** Memory is cheap, lost context is expensive.

## When to Recall (ALWAYS)

1. **Conversation start** → Recall last 7 days of work
2. **Before writing code** → Recall style preferences and patterns  
3. **Before decisions** → Recall similar past decisions
4. **When user references past** → Search for that specific context

```python
# Start of EVERY conversation
recall_memory(query="recent work current projects", limit=10)
```

## What to Store

### HIGH Priority (0.85+)
- **Corrections** - User fixes your output
- **Decisions** - Architectural choices, tool selections
- **Milestones** - Project completions, achievements

### MEDIUM Priority (0.7+)
- **Patterns** - Recurring preferences
- **Preferences** - Style choices, workflows
- **Insights** - Lessons learned

### LOW Priority (0.6+)
- **Context** - Current work state
- **Tasks** - What's being worked on

### DON'T Store
- Greetings, acknowledgments
- Temporary info (file paths, session IDs)
- Anything sensitive (passwords, keys)

## Key Patterns

### Pattern: Correction Capture
When user corrects you → Store with importance 0.9
```python
store_memory(
    content=f"Correction: {what} should be {correct}",
    type="Correction",
    importance=0.9,
    tags=["correction", context]
)
```

### Pattern: Decision Documentation  
When making choices → Include alternatives
```python
store_memory(
    content=f"Chose {choice} over {alternatives} for {reason}",
    type="Decision", 
    importance=0.85,
    metadata={"alternatives": alternatives, "factors": factors}
)
```

### Pattern: Progressive Search
Start broad → Narrow if needed
```python
# Step 1: Broad search
recall_memory(query="authentication", limit=5)

# Step 2: If insufficient, add specificity
recall_memory(query="oauth jwt auth", tags=["security"], limit=10)
```

## Quick Reference

| Trigger | Action |
|---------|--------|
| Conversation starts | Recall last 7 days |
| "As we discussed" | Search for that topic |
| User corrects output | Store correction (0.9) |
| Making a decision | Store with alternatives |
| Starting substantial task | Recall relevant patterns |
| "Remember that..." | Store immediately |

## Integration Checklist

- [ ] Start EVERY conversation with recall
- [ ] Capture ALL corrections as memories
- [ ] Document decisions with reasoning
- [ ] Use hierarchical tags (project:name, team:name)
- [ ] Skip memory for trivial interactions
